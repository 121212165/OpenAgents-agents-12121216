# 小游探 Docker 部署指南

## 🔧 问题修复

已修复以下Docker部署问题：
- ✅ 启动命令路径错误
- ✅ 文件复制路径问题  
- ✅ 健康检查配置
- ✅ Python模块导入问题

## 🚀 快速部署

### 方法1: Docker Compose (推荐)

```bash
# 1. 解压部署包
unzip yougame-deploy.zip
cd deploy-package

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env 文件（可选，已预配置）

# 3. 启动服务
docker-compose up -d

# 4. 查看日志
docker-compose logs -f

# 5. 健康检查
curl http://localhost:8000/health
```

### 方法2: 直接Docker

```bash
# 1. 构建镜像
docker build -t yougame-explorer .

# 2. 运行容器
docker run -d \
  --name yougame-explorer \
  -p 8000:8000 \
  --env-file .env \
  yougame-explorer

# 3. 查看日志
docker logs -f yougame-explorer
```

## 🏥 健康检查

访问健康检查端点：
```bash
curl http://localhost:8000/health
```

预期响应：
```json
{
  "status": "healthy",
  "timestamp": 1673123456.789,
  "agents": {
    "router": true,
    "live_monitor": true,
    "briefing_agent": true,
    "data_source_agent": true
  }
}
```

## 🔧 环境变量

已预配置的环境变量：
```bash
OPENAGENTS_HOST=0.0.0.0
OPENAGENTS_PORT=8000
OPENAI_API_KEY=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
OPENAI_BASE_URL=https://openrouter.ai/api/v1
OPENAI_MODEL=xiaomi/mimo-v2-flash:free
```

## 🐛 故障排查

### 容器启动失败
```bash
# 查看详细日志
docker logs yougame-explorer

# 检查容器状态
docker ps -a
```

### 端口占用
```bash
# 检查端口使用
netstat -tulpn | grep 8000

# 使用不同端口
docker run -p 8001:8000 yougame-explorer
```

### 健康检查失败
```bash
# 进入容器检查
docker exec -it yougame-explorer bash

# 手动测试启动
python start.py
```

## 📊 管理命令

```bash
# 停止服务
docker-compose down

# 重启服务
docker-compose restart

# 查看资源使用
docker stats yougame-explorer

# 清理
docker-compose down --volumes --rmi all
```

## 🌐 云端部署

此Docker配置已优化，支持：
- Sealos
- Zeabur  
- Railway
- Render
- 任何支持Docker的云平台

上传此部署包即可一键部署！